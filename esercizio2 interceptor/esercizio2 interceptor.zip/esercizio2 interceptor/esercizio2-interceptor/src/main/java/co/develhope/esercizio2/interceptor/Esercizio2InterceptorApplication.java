package co.develhope.esercizio2.interceptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Esercizio2InterceptorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Esercizio2InterceptorApplication.class, args);
	}

}
