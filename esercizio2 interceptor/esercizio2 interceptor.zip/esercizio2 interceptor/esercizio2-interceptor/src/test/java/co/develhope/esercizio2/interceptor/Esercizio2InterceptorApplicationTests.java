package co.develhope.esercizio2.interceptor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Esercizio2InterceptorApplicationTests {

	@Test
	void contextLoads() {
	}

}
